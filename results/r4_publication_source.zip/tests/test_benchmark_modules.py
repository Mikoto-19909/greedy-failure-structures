"""Check benchmark extraction boundaries and genuine pre-move task pickles."""

from __future__ import annotations

import ast
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from maxcover import benchmark
from maxcover import benchmark_artifacts, benchmark_planning
from maxcover import benchmark_associations, benchmark_statistics


PICKLE_CHECK = r"""
import dataclasses
import json
import pickle
import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from maxcover import benchmark, benchmark_planning
from maxcover.contracts import AlgorithmRunOptions
from maxcover.model import thaw_json_value
from maxcover.reproducibility import instance_id, instance_payload
fixture = Path(sys.argv[2])
expected = json.loads((fixture / 'expected.json').read_bytes())
for name, shape in expected['class_shapes'].items():
    cls = getattr(benchmark_planning, name)
    assert getattr(benchmark, name) is cls
    assert cls.__qualname__ == shape['qualname']
    assert list(cls.__slots__) == shape['slots']
    assert list(cls.__match_args__) == shape['match_args']
    assert cls.__dataclass_params__.frozen == shape['frozen']
    assert [f.name for f in dataclasses.fields(cls)] == shape['fields']
    for field in dataclasses.fields(cls):
        default = shape['defaults'][field.name]
        assert field.default_factory is dataclasses.MISSING
        if default['kind'] == 'missing':
            assert field.default is dataclasses.MISSING
        else:
            assert field.default == default['value']
for protocol in (4, 5):
    values = pickle.loads((fixture / f'planning_tasks_protocol{protocol}.pickle').read_bytes())
    assert set(values) == set(expected['cases'])
    for label, (planned, task) in values.items():
        old = expected['cases'][label]
        assert type(planned) is benchmark._PlannedInstance is benchmark_planning._PlannedInstance
        assert type(task) is benchmark._RunTask is benchmark_planning._RunTask
        assert type(task.options) is AlgorithmRunOptions
        assert planned.instance is task.instance
        for value, key, omitted in ((planned, 'planned', {'instance'}),
                                    (task, 'task', {'instance', 'options'}),
                                    (task.options, 'options', set())):
            observed = {field.name: thaw_json_value(getattr(value, field.name))
                        for field in dataclasses.fields(value) if field.name not in omitted}
            assert observed == old[key], (label, key, observed, old[key])
        assert list(planned.instance.sets) == old['instance']['ordered_masks']
        assert instance_payload(planned.instance, encoding='bitsets') == old['instance']['instance_payload']
        assert instance_id(planned.instance) == old['instance']['computed_instance_id']
        for value in (planned, task):
            assert not hasattr(value, '__dict__')
            try:
                value.case_id = 'changed'
            except dataclasses.FrozenInstanceError:
                pass
            else:
                raise AssertionError('loaded task must remain frozen')
        roundtrip = pickle.loads(pickle.dumps((planned, task), protocol=protocol))
        assert roundtrip == (planned, task)
        assert roundtrip[0].instance is roundtrip[1].instance
print('PASS: both old protocols preserve task contents, aliases and shared instances')
"""


class BenchmarkModuleTests(unittest.TestCase):
    def test_old_planning_pickles_load_in_a_new_interpreter(self) -> None:
        fixture = ROOT / "tests/fixtures/benchmark_planning"
        completed = subprocess.run(
            [sys.executable, "-c", PICKLE_CHECK, str(ROOT / "src"), str(fixture)],
            cwd=ROOT, capture_output=True, text=True, encoding="utf-8", timeout=30,
        )
        self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
        self.assertIn("PASS:", completed.stdout)

    def test_internal_modules_do_not_import_the_facade(self) -> None:
        for path in (ROOT / "src/maxcover").glob("benchmark_*.py"):
            with self.subTest(module=path.name):
                for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                    if isinstance(node, ast.ImportFrom):
                        self.assertNotIn(node.module, {"benchmark", "maxcover.benchmark"})
                        if node.module in {None, "maxcover"}:
                            self.assertNotIn("benchmark", [alias.name for alias in node.names])
                    elif isinstance(node, ast.Import):
                        self.assertNotIn("maxcover.benchmark", [alias.name for alias in node.names])

    def test_facade_aliases_remain_correct(self) -> None:
        for module, names in (
            (benchmark_planning, ("_PlannedInstance", "_RunTask", "_STRUCTURAL_COUPLING_INTENSITY",
                                  "_case_seed", "_coupling_pair_id", "_coupling_seed",
                                  "_fixed_size_control_pairs", "_instance_record", "_instances_for_config",
                                  "_resolved_case_parameters", "_structural_coupling_pair_id", "_tasks_for_config")),
            (benchmark_artifacts, ("REPORT_FILENAMES", "RUNNER_OWNED_FILENAMES",
                                   "SEARCH_COMPARISON_FIELDS", "STOCHASTIC_SUMMARY_FIELDS", "_runner_owned_paths",
                                   "_csv_text", "_canonical_run_records", "_canonical_instance_records", "_write_csv",
                                   "_validate_existing_instances", "_clean_runner_owned_artifacts",
                                   "_write_search_comparison", "_write_stochastic_summary", "_read_existing")),
            (benchmark_statistics, (
                "_validate_certificate_bound", "_normalize_optima", "_reference_status_records",
                "_reference_coverage_statistics", "_REFERENCE_BIAS_METRICS",
                "_reference_censoring_bias_statistics", "_reference_cutoff_sensitivity_statistics",
                "_summarize", "_MetricDescription", "_linear_quantile", "_describe_values",
                "_DescriptiveCommon", "_descriptive_statistics", "_beta_continued_fraction",
                "_regularized_incomplete_beta", "_student_t_cdf", "_student_t_critical_95",
                "_ten_decimal", "_ConfidenceIntervalCommon", "_confidence_interval_statistics",
                "_censored_runtime_statistics", "_greedy_failure_statistics", "_LocalSearchPairAnalysis",
                "_local_search_pair_analyses", "_local_search_recovery_statistics",
                "_local_search_remaining_gap_statistics", "_runtime_ratio_variant_units",
                "_heuristic_exact_runtime_ratio_statistics", "_bnb_variant_units",
                "_bnb_node_reduction_statistics", "_pareto_variant_units", "_quality_runtime_pareto_statistics",
                "_deterministic_variant_units", "_increment_heuristic_status",
            )),
            (benchmark_associations, (
                "_gap_density_association_statistics", "_gap_overlap_association_statistics",
                "_gap_clustering_association_statistics", "_runtime_set_count_association_statistics",
                "_RuntimeKInstanceProjection", "_runtime_k_association_statistics",
                "_search_nodes_dominated_ratio_association_statistics",
            )),
        ):
            for name in names:
                with self.subTest(name=name):
                    self.assertIs(getattr(benchmark, name), getattr(module, name))


if __name__ == "__main__":
    unittest.main()
