# Benchmark output guide

A completed benchmark writes canonical inputs, derived statistics, charts,
and reports beneath the selected output directory. The record
classes and schema constants in `src/maxcover/` remain the machine-readable
source of truth; this guide explains how the files relate to one another.

## Canonical instance and run artifacts

`instances.csv` records each generated instance and the identity needed to
reproduce it. Its fields include the case and family, deterministic seeds and
coupling identities, dimensions and generator parameters, measured structural
properties, and any validated known-optimum certificate.

`raw_results.csv` records every planned algorithm run. It carries the run and
instance identities, algorithm variant and options, status, incumbent coverage,
bound and reference fields, elapsed runtime, selected set indices, metadata,
and any operational error. Checkpoints are written in this format, and resume
uses the stable run identifier as its unit.

These two files are the canonical inputs consumed by `summarize`. Derived files
must be rebuildable from them and the matching configuration without executing
an algorithm.

## General aggregates

`summary.csv` is the compatibility aggregate retained for older consumers. Its
rows summarize raw runs directly and are not the canonical source for every
analysis.

`descriptive_statistics.csv` is the canonical typed aggregate for coverage,
optimality-gap, and completed-runtime metrics. It records the repetition unit,
eligible samples, timeout and error counts, exact-reference availability, and
descriptive statistics.

`confidence_interval_statistics.csv` contains two-sided intervals for eligible
instance-level means. A row remains present when its interval is not estimable;
the status explains why and unavailable numeric fields remain blank.

`censored_runtime_statistics.csv` records timeout censoring separately from
completed runtime observations. Timeout duration is not silently treated as a
completed runtime.

## Exact-reference coverage and censoring diagnostics

`reference_status.csv` contains one row for every generated instance. It records
the effective reference status, every enabled configured exact variant's status, the
proof sources, certificate availability, and cross-validation state. A solver
excluded by its configured set-count cutoff is recorded as `not_run`; it is not
silently omitted.

`reference_coverage_statistics.csv` groups those rows by family, normalized
generator parameters, and status. Its denominator is every generated instance
in the slice, and its numerator is the instances with at least one validated
optimum proof. The status rows distinguish `optimal`, `feasible`, `timeout`,
`error`, `known_optimum_certificate`, and `not_run` outcomes.

`reference_censoring_bias_statistics.csv` compares retained instances (a proved
reference exists) with excluded instances (no proof) within the same family and
parameter slice. It reports size and measured-structure means and the excluded
mean minus the retained mean. Comparisons remain blank unless both groups have
observations; no missing value is replaced with zero.

`reference_cutoff_sensitivity_statistics.csv` preserves each enabled configured exact
variant's time and set-count cutoffs, status counts, solver-only reference
coverage, and effective coverage after independently validated certificates are
included. Configure multiple variants with different cutoffs to obtain a direct
sensitivity comparison on the same generated instances.

When brute force and Branch-and-Bound or CP-SAT both prove an optimum for the
same eligible small instance, `reference_status.csv` marks that cross-check.
Any disagreement between optimal exact sources or a known-optimum certificate
already stops normalization with an error.

## Paired algorithm analyses

The runner writes these typed files for each completed benchmark. Rows require
the corresponding variants and eligible instance-level observations or pairs;
files remain header-only when no rows apply:

- `greedy_failure_statistics.csv`: Greedy outcomes paired with valid optimal
  references
- `local_search_recovery_statistics.csv`: recovery from Greedy failures
- `local_search_remaining_gap_statistics.csv`: residual exact-reference gap
  after local search
- `heuristic_exact_runtime_ratio_statistics.csv`: completed heuristic/exact
  runtime pairs
- `bnb_node_reduction_statistics.csv`: baseline/enhanced branch-and-bound node
  comparisons
- `quality_runtime_pareto_statistics.csv`: eligible quality/runtime frontier
  classification

`search_comparison.csv` is written only when `bnb_baseline` and `bnb_enhanced`
runs share an instance. `stochastic_summary.csv` is written only when an
explicitly seeded algorithm run has a feasible coverage value. These
compatibility outputs are conditional, unlike the typed files listed above.

## Structural gap cartography artifacts

The `cartography` command adds a local analysis package:

- `structural_gap_statistics.csv` reports `1 - coverage / optimum` by stressor
  family, strength, treatment/control role, algorithm, and instance seed. It
  includes the mean, median, sample standard deviation, quartiles, range, and a
  two-sided Student-t confidence interval.
- `paired_control_differences.csv` reports seed-paired
  `stressor_gap - control_gap` distributions with the same descriptive and
  interval fields. Missing exact references are counted and excluded.
- `precision_diagnostics.csv` estimates the seed count needed to reach the
  design's fixed confidence-interval half-width target using the observed
  paired-difference standard deviation.
- `stressor_strength_gap.svg` plots stressor strength against mean gap and its
  interval for each heuristic algorithm.
- `family_algorithm_gap.svg` is the family-by-algorithm map, using an
  equal-weight mean across the configured strength-level means.

`validate_cartography_output.py` does not trust those hashes as proof of the
calculation. It independently rebuilds the instance-seed aggregates, paired
differences, intervals, and precision diagnostics from `raw_results.csv`, then
checks the complete execution-plan identities and stored values against the raw
results and design. An absent planned run is rejected even if derived tables
have been rebuilt; a present error record can still contribute a missing gap.
Generated instances also check the instance table and selected-set coverage.
Optimum references come from optimal exact-run records or regenerated
certificates; stored optimum/gap values must agree with these references.
Ordinary cartography resumes also remove a retired `cartography_manifest.json`
before refreshing their analysis artifacts. Rejected configuration, design, or
checkpoint inputs leave it untouched.
The paired-analysis CLI similarly removes an old `analysis_manifest.json` only
after both inputs pass validation, before writing refreshed comparison files.

For algorithms with multiple `algorithm_seeds`, one instance contributes the
arithmetic mean of its complete algorithm-seed gaps. The independent unit for
distribution and interval calculations is therefore the generated instance
seed, not an individual randomized-algorithm run.

## Structural association analyses

The following files associate instance-equal response values with measured or
configured structural predictors. They retain eligibility counts and an
association status for missing or constant data:

- `gap_density_association_statistics.csv`
- `gap_overlap_association_statistics.csv`
- `gap_clustering_association_statistics.csv`
- `runtime_set_count_association_statistics.csv`
- `runtime_k_association_statistics.csv`
- `search_nodes_dominated_ratio_association_statistics.csv`

These are descriptive associations. They do not establish causation,
statistical significance, or support for more elaborate survival or nonlinear
modeling.

## Reports and charts

`results_summary.md` renders a local human-readable report from the typed
statistics. The SVG artifacts visualize gap, runtime, structural association,
local-search recovery, quality/runtime, search-node, and timeout views. Their
filenames are enumerated by `REPORT_FILENAMES` in
[`benchmark.py`](../src/maxcover/benchmark.py).

`reference_coverage_by_case.svg` is the cartography missingness layer. Its bars
use all generated instances and preserve the unresolved reference statuses
instead of displaying only the instances eligible for gap analysis.

A header-only CSV or a chart with no applicable typed rows is a valid artifact.
It means the configured run did not supply the inputs required by that analysis;
it does not mean the metric equals zero.

## Status and exact-reference semantics

- `optimal` means an exact method closed its bound and may supply a reference
  optimum.
- `feasible` means an incumbent is available without an optimality proof.
  Check `algorithm_metadata.termination` separately: this status can accompany
  a time or iteration limit and does not establish completed execution.
- `timeout` means work stopped at its configured limit; an incumbent or bound
  may be present, but the timeout run itself does not prove an optimum. The
  normalized row may still carry a reference optimum from an independently
  validated instance certificate or another exact run for the same instance.
- `error` means no valid algorithm result was produced.
- `known_optimum_certificate` means the generator supplied an independently
  validated feasible solution and optimum upper-bound proof.
- `not_run` is a derived reference-diagnostic status used when a configured
  exact variant is ineligible under its set-count cutoff, or when no exact
  source was configured. It is not an algorithm `SolutionStatus`.

Failure rates, relative gaps, and other optimum-relative analyses require a
valid optimal reference for the same instance. Blank values express
ineligibility or unavailable data and must not be interpreted as zero.

## Replay artifacts

The runner writes self-contained JSON files under `failures/` for replayable
timeout or error cases. Each file includes the serialized instance, recorded
algorithm identity and options, and the result fields used for comparison. The
`replay` command can use the recorded algorithm or an explicit replacement, but
the replacement receives the recorded options and must accept that option
contract; replay does not translate options between algorithms.

## Optional output validation

The runner writes CSV results and reports without a manifest or file checksums.
Configuration, instance, and run hashes remain internal identifiers for result
joins and resume. Keep the experiment configuration with its results.
Ordinary runs, resume, and summarize remove a retired `manifest.json` after
checking the existing inputs, before writing refreshed outputs. Rejected inputs
leave the existing results and legacy metadata in place.

For detailed checks on a completed run:

```console
python .github/scripts/validate_benchmark_output.py --config configs/quick.json --output results/quick
```

The validator checks configuration and execution-plan identities, record
consistency, supported statistics recomputed from `raw_results.csv` and
`instances.csv`, summary groups, and selected charts.
It shares calculation and rendering helpers with the producer. It does not
replay every algorithm or check legacy charts. Markdown headings, paragraphs,
and layout are outside its scope, including manually edited report numbers.
Review prose against its source data; passing this validator does not establish
that a report's written conclusions are correct. This command
requires completed runs and an optimum reference for every instance, so it is
not a general check for exploratory timeout or missing-reference outputs.

The [core overlap analysis](../analysis/core_overlap_pilot.py) reads the two CSVs
directly and checks sample pairing, completion, optimal reference status, and
selected-set coverage against generated instances. It writes the paired table,
report, and figure. No ledger or separate validation record is required.

Reports in `analysis/` should link directly to their configuration and data in
`experiments/core_rq/`. The [document outlines](../CONTRIBUTING.md#document-structure)
provide a readable default structure without imposing fixed wording.
