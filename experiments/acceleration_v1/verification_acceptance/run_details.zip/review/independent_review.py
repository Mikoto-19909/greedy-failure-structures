from pathlib import Path
import sys, itertools, math, copy, subprocess, warnings
from unittest.mock import patch
ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT/'analysis'), str(ROOT/'src')]
import verification_completion as b
from r2_design import make_design, read_json, write_json
from r2_budget_grid import run, analyze
from validate_r2_budget_grid import verify_graph

def reference(sets,k,prefix):
    valid = []
    for bits in itertools.product((0,1),repeat=len(sets)):
        chosen = [i for i,bit in enumerate(bits) if bit]
        if len(chosen)!=k or not set(prefix).issubset(chosen):
            continue
        value = sum(any(e in sets[i] for i in chosen) for e in set().union(*sets))
        valid.append((value,chosen))
    best = max(value for value,_ in valid)
    return best,min(chosen for value,chosen in valid if value==best),len(valid),sum(value==best for value,_ in valid)

def main():
    solve=b.get_completion_solver('numba')
    cases=[[],[set() for _ in range(6)],[{10**30} for _ in range(6)],
           [{-100,100},{100},{0},{-100,0},set(),{0,100}],
           [{i,i+1} for i in range(6)]]
    count=0
    for sets in cases:
        for k in range(len(sets)+1):
            for length in range(k+1):
                for p in itertools.combinations(range(len(sets)),length):
                    prefix=list(reversed(p))
                    actual=solve(sets,k,prefix,100000)
                    expected=reference(sets,k,prefix)
                    assert actual==expected,(sets,k,prefix,actual,expected)
                    count+=1
    print('independent powerset comparisons',count,flush=True)
    for k,prefix,limit in [(2,[-1],100),(2,[6],100),(2,[1,1],100),(1,[3,0],100),(True,[],100),(2,[1.0],100),(2,[],14)]:
        try: solve(cases[-1],k,prefix,limit)
        except ValueError: pass
        else: raise AssertionError(('invalid accepted',k,prefix,limit))
    try: solve([set() for _ in range(68)],34,[],math.comb(68,34))
    except ValueError as e: assert 'integer range' in str(e)
    else: raise AssertionError('overflow accepted')
    print('invalid prefixes/budget and integer overflow rejected',flush=True)
    b.get_completion_solver.cache_clear(); b._optional_solver.cache_clear()
    with patch.object(b,'_build_solver',side_effect=b.FastVerificationUnavailable('review injected unavailable')):
        with warnings.catch_warnings(record=True) as seen:
            warnings.simplefilter('always')
            assert b.get_completion_solver('auto')([{1}],1,[],1)==(1,[0],1,1)
        assert len(seen)==1
        try: b.get_completion_solver('numba')
        except b.FastVerificationUnavailable: pass
        else: raise AssertionError('required numba fell back')
    b.get_completion_solver.cache_clear(); b._optional_solver.cache_clear()
    def broken(*args): raise RuntimeError('review injected calculation fault')
    with patch.object(b,'_build_solver',return_value=broken):
        try: b.get_completion_solver('auto')([{1}],1,[],1)
        except RuntimeError as e: assert 'calculation fault' in str(e)
        else: raise AssertionError('runtime calculation error hidden')
    b.get_completion_solver.cache_clear(); b._optional_solver.cache_clear()
    out=Path(__file__).parent/'batch_n5_d3'
    design=make_design('fixture',(5,),(3,),2,1)
    run(design,out,workers=1)
    analyze(out,plot=False,verification_workers=1)
    names=('config.json','cell_summary.csv','budget_results.csv','mechanism_summary.csv')
    before={name:(out/name).read_bytes() for name in names}
    for args in [
        ['validate_r2_budget_grid.py','--output',out,'--workers','2','--verification-backend','numba'],
        ['r2_budget_grid.py','analyze','--output',out,'--no-plot','--verification-workers','2','--verification-backend','numba']]:
        result=subprocess.run([sys.executable,str(ROOT/'analysis'/args[0]),*map(str,args[1:])],cwd=ROOT,text=True,capture_output=True,timeout=90)
        assert result.returncode==0,result.stdout+result.stderr
        print('CLI passed:',args[0],flush=True)
    assert all((out/name).read_bytes()==data for name,data in before.items())
    graph=out/'graphs'/(design['tasks'][0]['base_graph_id']+'.json')
    damaged=read_json(graph)
    damaged['diagnostic']['prefixes'][0]['completion_selected']=[4]*design['tasks'][0]['diagnostic_k']
    write_json(graph,damaged)
    result=subprocess.run([sys.executable,str(ROOT/'analysis/validate_r2_budget_grid.py'),'--output',str(out),'--workers','2','--verification-backend','numba'],cwd=ROOT,text=True,capture_output=True,timeout=90)
    assert result.returncode!=0 and 'completion_selected' in result.stderr,result.stderr
    assert read_json(out/'verification.json')['status']=='incomplete'
    try: analyze(out,plot=False,completion_backend='numba',verification_workers=1)
    except ValueError as e: assert 'completion_selected' in str(e)
    else: raise AssertionError('damaged witness accepted')
    assert all((out/name).read_bytes()==data for name,data in before.items())
    print('spawn damaged-witness refusal, incomplete status and previous CSV preservation passed',flush=True)

if __name__=='__main__': main()
